python main.py --config configs/imagedream.yaml input=data/rabbit_chinese_rgba.png prompt="a standing white rabbit in red traditional chinese clothes" save_path=rabbit
python main2.py --config configs/imagedream.yaml input=data/rabbit_chinese_rgba.png prompt="a standing white rabbit in red traditional chinese clothes" save_path=rabbit

python main.py --config configs/imagedream.yaml input=data/astronaut_rgba.png prompt="an astronaut riding a horse" save_path=astro
python main2.py --config configs/imagedream.yaml input=data/astronaut_rgba.png prompt="an astronaut riding a horse" save_path=astro

python main.py --config configs/imagedream.yaml input=data/ghost_rgba.png prompt="a ghost eating hamburger" save_path=ghost
python main2.py --config configs/imagedream.yaml input=data/ghost_rgba.png prompt="a ghost eating hamburger" save_path=ghost
