import { useState } from "react";
import axios from "axios";
import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import ModelViewer from "./components/ModelViewer";


function App() {
  const [file, setFile] = useState(null);
  const [modelUrl, setModelUrl] = useState("");

  const uploadAndGenerate = async () => {
    const formData = new FormData();
    formData.append("image", file);
    const response = await axios.post("http://localhost:8000/generate_3d/", formData);
    setModelUrl(response.data.file_path);
  };

  return (
    <div>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={uploadAndGenerate}>生成 3D</button>
      {modelUrl && (
        <Canvas>
          <OrbitControls />
          <ModelViewer url={modelUrl} />
        </Canvas>
      )}
    </div>
  );
}

export default App;
