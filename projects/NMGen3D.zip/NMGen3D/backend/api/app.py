import os
import uvicorn
from fastapi import FastAPI, UploadFile
from nerf.run_nerf import generate_nerf_3d  # 導入 NeRF 生成函式

app = FastAPI()

# 設定輸出資料夾
OUTPUT_DIR = "outputs/"
os.makedirs(OUTPUT_DIR, exist_ok=True)

@app.post("/generate_3d/")
async def generate_3d(file: UploadFile):
    """ 使用 NeRF 生成 3D 模型 """
    input_path = os.path.join(OUTPUT_DIR, file.filename)
    output_path = os.path.join(OUTPUT_DIR, file.filename.replace(".jpg", ".obj"))

    # 儲存上傳的圖片
    with open(input_path, "wb") as buffer:
        buffer.write(file.file.read())

    # 執行 NeRF 生成 3D
    generate_nerf_3d(input_path, output_path)

    return {"3D_model": output_path}

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
