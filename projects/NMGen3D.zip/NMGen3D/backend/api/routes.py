from flask import Flask, request, jsonify
import os
import tensorflow as tf
from utils import generate_3d_mesh  # 假設此函數會處理與 TensorFlow 的交互

app = Flask(__name__)

@app.route('/generate_3d', methods=['POST'])
def generate_3d():
    if 'image' not in request.files:
        return jsonify({"error": "No image file provided"}), 400
    
    image = request.files['image']
    
    # 儲存圖片至本地磁碟
    image_path = os.path.join('inputs', image.filename)
    image.save(image_path)

    output_path = os.path.join('outputs', 'generated_model.obj')
    
    # 假設 generate_3d_mesh 現在是與 TensorFlow 模型互動來生成 3D 模型
    try:
        generate_3d_mesh(image_path, output_path)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
    return jsonify({"message": "3D model generated successfully", "model_path": output_path}), 200

if __name__ == '__main__':
    app.run(debug=True)
