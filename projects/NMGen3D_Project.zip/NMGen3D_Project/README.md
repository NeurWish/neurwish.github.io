# NMGen3D_Project

這是一個 3D 生成專案，從單張圖片生成完整的 3D 模型，並支援 NeRF / COLMAP 重建。

## 🚀 功能
- **生成多視角圖片**：使用 AI（Stable Diffusion + ControlNet）生成不同視角。
- **深度估計**：使用 MiDaS / DPT 計算深度圖。
- **點雲生成**：根據深度圖生成點雲。
- **3D 重建**：使用 Poisson Surface Reconstruction 轉換為 Mesh。
- **模型優化**：修正法線、網格簡化，提升 3D 精度。
- **NeRF 輸出**：可用於 Instant-NGP 進行高品質 3D 重建。

## 📂 專案結構
請參考 `NMGen3D_Project` 資料夾結構。

## 🔧 安裝
```bash
pip install -r requirements.txt


source ~/pytorch-env/bin/activate