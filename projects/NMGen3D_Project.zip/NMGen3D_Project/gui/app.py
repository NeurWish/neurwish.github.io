import sys
import os
import locale
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QFileDialog, QProgressBar
from PyQt5.QtGui import QPixmap, QFont
from PyQt5.QtCore import Qt
from scripts.generate_views import generate_views
from scripts.estimate_depth import estimate_depth
from scripts.create_point_cloud import create_point_cloud
from scripts.reconstruct_mesh import reconstruct_mesh
from scripts.optimize_mesh import optimize_mesh
from scripts.export_nerf import export_nerf
import open3d as o3d

# 設定 GUI 預設字型為 UTF-8
locale.setlocale(locale.LC_ALL, "C.UTF-8")

# 設定字型
font = QFont("WenQuanYi Zen Hei", 12)  # Linux: 文泉驭正黑
QApplication.setFont(font)

class NMGen3DApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("NMGen3D - 3D 生成器")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        self.label = QLabel("請選擇一張圖片:")
        self.label.setFont(QFont("Arial", 12))
        self.label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.label)

        self.button = QPushButton("選擇圖片")
        self.button.setFont(QFont("Arial", 10))
        self.button.clicked.connect(self.openFileDialog)
        layout.addWidget(self.button)

        self.progress = QProgressBar()
        layout.addWidget(self.progress)

        self.setLayout(layout)

    def openFileDialog(self):
        options = QFileDialog.Options()
        filePath, _ = QFileDialog.getOpenFileName(self, "選擇圖片", "", "Images (*.png *.jpg *.jpeg)", options=options)

        if filePath:
            print(f"👤 選擇圖片: {filePath}")
            self.label.setText(f"✅ 已選擇: {filePath}")
            self.processImage(filePath)

    def processImage(self, input_image):
        if not os.path.exists(input_image):
            print(f"❌ 圖片不存在: {input_image}")
            return
        
        base_name = os.path.basename(input_image).split('.')[0]
        self.progress.setValue(10)
        
        # 生成新視角圖片
        generated_views = generate_views(input_image, output_dir="data/generated_views/")
        if not generated_views or not isinstance(generated_views, list):
            print(f"❌ 生成視角圖片失敗，請檢查 `generate_views()` 的輸出。")
            return
        
        self.progress.setValue(30)

        depth_maps = []
        for img in generated_views:
            if not os.path.exists(img):
                print(f"❌ 沒有找到圖片: {img}")
                continue  # 跳過無效的圖片
            
            depth_map = estimate_depth(img, output_dir="data/depth_maps/")
            if depth_map:
                depth_maps.append(depth_map)
        
        self.progress.setValue(50)

        if not depth_maps:
            print(f"❌ 無法生成深度圖，請檢查輸入圖片！")
            return

        os.makedirs("data/point_clouds/", exist_ok=True)
        os.makedirs("data/meshes/", exist_ok=True)
        os.makedirs("data/output/", exist_ok=True)
        
        point_cloud = create_point_cloud(depth_maps, output_path=f"data/point_clouds/{base_name}.ply")
        self.progress.setValue(70)

        mesh_file = reconstruct_mesh(point_cloud, output_path=f"data/meshes/{base_name}.obj")
        self.progress.setValue(85)

        optimized_mesh = optimize_mesh(mesh_file, output_path=f"data/output/{base_name}_final.obj")
        self.progress.setValue(95)

        self.show3DModel(optimized_mesh)
        self.progress.setValue(100)
        self.label.setText("✅ 3D 生成完成！")

    def show3DModel(self, mesh_path):
        if not os.path.exists(mesh_path):
            print(f"❌ 沒有找到模型: {mesh_path}")
            return
        mesh = o3d.io.read_triangle_mesh(mesh_path)
        o3d.visualization.draw_geometries([mesh])

if __name__ == '__main__':
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling)
    app = QApplication(sys.argv)
    ex = NMGen3DApp()
    ex.show()
    sys.exit(app.exec_())