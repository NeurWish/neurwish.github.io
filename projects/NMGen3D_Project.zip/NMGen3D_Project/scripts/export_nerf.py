import os
import json

def export_nerf(mesh_path, output_path="data/output/nerf_format.json"):
    """
    將 3D Mesh 轉換為 NeRF 格式（JSON 描述）。
    """
    if not os.path.exists(os.path.dirname(output_path)):
        os.makedirs(os.path.dirname(output_path))
    
    nerf_data = {
        "mesh_file": mesh_path,
        "metadata": {
            "format": "NeRF-compatible",
            "generated_by": "NMGen3D"
        }
    }
    
    with open(output_path, "w") as f:
        json.dump(nerf_data, f, indent=4)
    
    return output_path