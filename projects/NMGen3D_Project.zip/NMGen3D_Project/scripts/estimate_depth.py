import os
import torch
import cv2
import numpy as np
from PIL import Image
from torchvision.transforms import Compose, ToTensor, Normalize
from models.MiDaS.MiDaS.model_loader import load_model

def estimate_depth(input_image, output_dir="data/depth_maps/"):
    """
    計算圖片的深度圖，確保所有設備和模型都正確載入。
    """

    # **🚀 確保 `input_image` 是 NumPy 陣列**
    if isinstance(input_image, Image.Image):
        print("🔹 input_image 是 PIL.Image，轉換為 NumPy 陣列...")
        input_image = np.array(input_image)  # 轉為 NumPy 陣列
        input_image = cv2.cvtColor(input_image, cv2.COLOR_RGB2BGR)  # 轉換為 BGR 格式

    elif isinstance(input_image, np.ndarray):
        print("🔹 input_image 已經是 NumPy 陣列，跳過轉換。")

    elif isinstance(input_image, str):
        if not os.path.exists(input_image):
            raise FileNotFoundError(f"❌ 找不到圖片檔案: {input_image}")
        input_image = cv2.imread(input_image)
        if input_image is None:
            raise ValueError(f"❌ OpenCV 無法讀取圖片: {input_image}")

    else:
        raise TypeError(f"❌ 不支援的輸入類型: {type(input_image)}")

    # **🚀 檢查輸入圖像大小**
    if input_image is None or input_image.shape[0] == 0 or input_image.shape[1] == 0:
        raise ValueError(f"❌ `input_image` 無效，請檢查圖片內容: shape={input_image.shape}")

    # 確保輸出目錄存在
    os.makedirs(output_dir, exist_ok=True)

    # **選擇裝置**
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # **載入 MiDaS 深度估計模型**
    model_filename = "dpt_beit_large_512.pt"
    model_dir = os.path.abspath("models/MiDaS/weights")
    model_path = os.path.join(model_dir, model_filename)

    if not os.path.isfile(model_path):
        raise FileNotFoundError(f"❌ 模型權重檔案不存在: {model_path}")

    print(f"✅ 使用模型: {model_path}")
    print(f"✅ 使用裝置: {device}")

    # **🚀 載入模型**
    model, transform, net_w, net_h = load_model(device, model_path)

    # **🚀 檢查 `net_w` 和 `net_h`**
    if net_w <= 0 or net_h <= 0:
        raise ValueError(f"❌ `net_w` 或 `net_h` 為 0，無法調整圖片大小: net_w={net_w}, net_h={net_h}")

    # **🚀 預處理圖片**
    sample = {"image": input_image.astype(np.float32) / 255.0}
    sample["image"] = np.ascontiguousarray(sample["image"])

    # **🚀 嘗試應用 MiDaS 模型的 `transform()`**
    try:
        transformed_sample = transform(sample)
    except Exception as e:
        raise ValueError(f"❌ `transform(sample)` 失敗: {e}")

    # **🚀 轉換為 PyTorch Tensor**
    print(f"Shape of transformed_sample['image']: {transformed_sample['image'].shape}") # 印出 shape

    img_tensor = torch.tensor(transformed_sample["image"]).unsqueeze(0).to(device) # 移除 permute

    # **使用 torch.cuda.amp.autocast 執行深度預測**
    with torch.no_grad():
        with torch.cuda.amp.autocast(enabled=True):  # 啟用混合精度
            depth_map = model(img_tensor)

    depth_map = depth_map.squeeze().cpu().numpy()

    # **將深度圖正規化到 0-255**
    depth_map = (depth_map - depth_map.min()) / (depth_map.max() - depth_map.min()) * 255
    depth_map = depth_map.astype(np.uint8)

    # **儲存深度圖**
    output_path = os.path.join(output_dir, "depth_map.png")
    cv2.imwrite(output_path, depth_map)

    print(f"✅ 深度圖儲存完成: {output_path}")

    return output_path