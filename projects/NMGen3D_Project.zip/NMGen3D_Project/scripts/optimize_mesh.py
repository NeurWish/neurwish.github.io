import os
import open3d as o3d

def optimize_mesh(mesh_path, output_path="data/output/optimized_mesh.obj"):
    """
    簡化並優化 3D Mesh。
    """
    if not os.path.exists(os.path.dirname(output_path)):
        os.makedirs(os.path.dirname(output_path))
    
    mesh = o3d.io.read_triangle_mesh(mesh_path)
    
    # 平滑處理
    mesh = mesh.filter_smooth_simple(number_of_iterations=5)
    
    # 頂點數量簡化
    mesh = mesh.simplify_quadric_decimation(target_number_of_triangles=int(len(mesh.triangles) * 0.5))
    
    # 計算法線
    mesh.compute_vertex_normals()
    
    # 儲存優化後的 Mesh
    o3d.io.write_triangle_mesh(output_path, mesh)
    return output_path
