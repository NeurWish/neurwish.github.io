import torch
import cv2
import numpy as np
from PIL import Image
import open3d as o3d
from scripts.estimate_depth import estimate_depth
from scripts.create_point_cloud import create_point_cloud
from scripts.render_360_views import render_360_views


def generate_views(input_image_path, output_dir="data/views/", num_views=36, poisson_depth=9):
    """
    進階版：使用 Poisson 表面重建（可調整深度），生成高品質且穩定的 Mesh，並渲染 360° 視角圖片。
    """

    # 讀取輸入影像
    image = Image.open(input_image_path).convert("RGB")

    # 估算深度圖 (MiDaS)
    depth_map_path = estimate_depth(image, output_dir="data/depth_maps/")

    # 確保深度圖正確讀取
    depth_map = cv2.imread(depth_map_path, cv2.IMREAD_GRAYSCALE)
    if depth_map is None:
        raise ValueError(f"❌ 無法讀取深度圖: {depth_map_path}")

    # 生成點雲
    point_cloud_path = create_point_cloud(depth_map_path, output_ply="data/point_clouds/point_cloud.ply")

    # 載入點雲
    pcd = o3d.io.read_point_cloud(point_cloud_path)
    pcd.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.1, max_nn=30))

    # 使用 Poisson Reconstruction 生成 Mesh (增加深度改善細節)
    mesh, densities = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(pcd, depth=poisson_depth)

    # 根據密度篩選 Mesh，移除低密度頂點提升品質
    densities = np.asarray(densities)
    density_threshold = np.quantile(densities, 0.05)
    vertices_to_remove = densities < density_threshold
    mesh.remove_vertices_by_mask(vertices_to_remove)

    # 檢查並修補 Mesh 中可能的問題
    mesh.remove_unreferenced_vertices()
    mesh.remove_degenerate_triangles()
    mesh.remove_duplicated_triangles()
    mesh.remove_duplicated_vertices()

    # 儲存重建後的 Mesh
    reconstructed_mesh_path = "data/meshes/reconstructed_mesh.ply"
    o3d.io.write_triangle_mesh(reconstructed_mesh_path, mesh)

    # 使用新生成的 Mesh 渲染360°視角圖片
    rendered_views_dir = render_360_views(reconstructed_mesh_path, output_dir="data/rendered_views/", num_views=num_views)

    print(f"✅ 改善版360°視角影像已儲存於: {rendered_views_dir}")
    return rendered_views_dir


# 測試執行
if __name__ == "__main__":
    generate_views("data/input_image.png", poisson_depth=10)
