import os
import open3d as o3d

def reconstruct_mesh(point_cloud_path, output_path="data/meshes/reconstructed_mesh.obj"):
    """
    使用 Poisson Surface Reconstruction 生成 3D Mesh。
    """
    if not os.path.exists(os.path.dirname(output_path)):
        os.makedirs(os.path.dirname(output_path))
    
    pcd = o3d.io.read_point_cloud(point_cloud_path)
    
    # 計算法線
    pcd.estimate_normals()
    
    # Poisson 重建
    mesh, densities = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(pcd, depth=8)
    
    # 儲存 Mesh
    o3d.io.write_triangle_mesh(output_path, mesh)
    return output_path
