import os
import numpy as np
import open3d as o3d
import cv2

def create_point_cloud(depth_map_path, output_ply="data/point_clouds/point_cloud.ply"):
    """
    根據深度圖生成點雲，並計算法線。
    """
    if not os.path.exists(os.path.dirname(output_ply)):
        os.makedirs(os.path.dirname(output_ply))
    
    # 讀取深度圖
    depth_map = cv2.imread(depth_map_path, cv2.IMREAD_UNCHANGED)
    h, w = depth_map.shape

    fx, fy = w / 2, h / 2
    cx, cy = w / 2, h / 2
    
    points = []
    colors = []
    
    for v in range(h):
        for u in range(w):
            depth = depth_map[v, u]
            if depth > 0:
                x = (u - cx) * depth / fx
                y = (v - cy) * depth / fy
                z = depth
                points.append((x, y, z))
                colors.append((depth / 255.0, depth / 255.0, depth / 255.0))
    
    # 生成點雲
    point_cloud = o3d.geometry.PointCloud()
    point_cloud.points = o3d.utility.Vector3dVector(points)
    point_cloud.colors = o3d.utility.Vector3dVector(colors)
    
    # ✅ 調整點雲法線計算
    point_cloud.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.3, max_nn=50))

    # 儲存點雲
    o3d.io.write_point_cloud(output_ply, point_cloud)

    print(f"✅ 點雲已生成: {output_ply}，並計算法線")
    return output_ply
