import os
import argparse
from scripts.generate_views import generate_views
from scripts.estimate_depth import estimate_depth
from scripts.create_point_cloud import create_point_cloud
from scripts.reconstruct_mesh import reconstruct_mesh
from scripts.optimize_mesh import optimize_mesh
from scripts.export_nerf import export_nerf
from PyQt5.QtWidgets import QApplication
from gui.app import NMGen3DApp

def main():
    parser = argparse.ArgumentParser(description="NMGen3D 生成 3D 模型")
    parser.add_argument("--cli", action="store_true", help="使用命令行模式")
    parser.add_argument("--input", type=str, help="輸入圖片路徑")
    args = parser.parse_args()

    if args.cli and args.input:
        base_name = os.path.basename(args.input).split('.')[0]

        print("🔹 生成多視角圖片...")
        generated_views = generate_views(args.input, output_dir="data/generated_views/")

        print("🔹 計算深度圖...")
        depth_maps = [estimate_depth(img, output_dir="data/depth_maps/") for img in generated_views]

        print("🔹 生成點雲...")
        point_cloud = create_point_cloud(depth_maps, output_path=f"data/point_clouds/{base_name}.ply")

        print("🔹 轉換為 3D Mesh...")
        mesh_file = reconstruct_mesh(point_cloud, output_path=f"data/meshes/{base_name}.obj")

        print("🔹 優化 3D 模型...")
        optimized_mesh = optimize_mesh(mesh_file, output_path=f"data/output/{base_name}_final.obj")

        print("🔹 轉換為 NeRF 格式...")
        export_nerf(optimized_mesh, output_path=f"data/output/{base_name}_nerf.json")

        print("✅ 3D 生成完成！")
    else:
        print("🔹 啟動 GUI 模式...")
        app = QApplication([])
        ex = NMGen3DApp()
        ex.show()
        app.exec_()

if __name__ == "__main__":
    main()
